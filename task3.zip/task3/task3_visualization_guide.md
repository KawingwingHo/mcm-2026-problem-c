# Task 3: 可视化方案指南
## Visualization Guide for MCM Paper (O-Award Standard)

---

## 1. 方法论框架图 (Methodology Framework)

### Figure 1: 双轨归因分析框架 (Dual-Track Attribution Framework)

```mermaid
flowchart TB
    subgraph Input["数据输入层"]
        A["Task 1 Output:<br/>s_fan (粉丝强度)"]
        B["Raw Data:<br/>Judge Scores"]
        C["Celebrity Features:<br/>Age, Industry, Partner, State"]
    end
    
    subgraph Model["双轨回归模型"]
        D["Model A:<br/>Y_judge = β₀ + β₁·Age + β₂·Industry + γ·Partner"]
        E["Model B:<br/>Y_fan = β₀ + β₁·Age + β₂·Industry + γ·Partner"]
    end
    
    subgraph Tests["统计检验层"]
        F["Welch's t-test<br/>(系数差异检验)"]
        G["ICC Analysis<br/>(舞伴效应)"]
        H["ANOVA<br/>(行业效应)"]
    end
    
    subgraph Output["结论输出"]
        I["年龄效应差异: 2.4x"]
        J["舞伴效应差异: 3.28x"]
        K["地区效应: η²=9.5%"]
    end
    
    A --> D
    A --> E
    B --> D
    C --> D
    C --> E
    
    D --> F
    E --> F
    D --> G
    E --> G
    D --> H
    E --> H
    
    F --> I
    G --> J
    H --> K
```

---

## 2. 核心结果可视化

### Figure 2: 年龄效应对比 (Age Effect Comparison)

**图表类型**: 双条形图 + 误差线 (Grouped Bar Chart with Error Bars)

**推荐工具**: matplotlib / plotly

```python
# 示例代码框架
import matplotlib.pyplot as plt
import numpy as np

categories = ['Judge Model', 'Fan Model']
betas = [-0.0588, -0.1405]
errors = [0.0076, 0.0195]  # Standard errors

fig, ax = plt.subplots(figsize=(8, 6))
bars = ax.bar(categories, betas, yerr=[1.96*e for e in errors], 
              capsize=5, color=['#3498db', '#e74c3c'], alpha=0.8)

ax.axhline(y=0, color='gray', linestyle='--', linewidth=0.8)
ax.set_ylabel('Regression Coefficient (β)')
ax.set_title('Age Effect: Judge vs Fan Model')
ax.annotate('2.4x difference\n(p < 0.001)', xy=(0.5, -0.10), 
            fontsize=12, ha='center')

plt.tight_layout()
plt.savefig('age_effect_comparison.png', dpi=300)
```

**图表说明**:
- 两个条形分别代表评委模型和粉丝模型的年龄系数
- 误差线表示 95% 置信区间
- 标注 2.4 倍差异和 p 值

---

### Figure 3: 职业舞伴 ICC 对比 (Partner Effect ICC Comparison)

**图表类型**: 堆叠条形图 (Stacked Bar Chart) 或 饼图对 (Paired Pie Charts)

```mermaid
pie title 评委模型方差分解
    "Partner Effect (16.4%)" : 16.4
    "Other Factors (83.6%)" : 83.6
```

```mermaid
pie title 粉丝模型方差分解
    "Partner Effect (5.0%)" : 5.0
    "Other Factors (95.0%)" : 95.0
```

**推荐设计**:
- 左右并排两个饼图
- 突出显示 Partner Effect 的比例差异
- 添加 "3.28x" 的标注箭头

---

### Figure 4: 行业效应热力图 (Industry Effect Heatmap)

**图表类型**: 热力图 (Heatmap)

**数据结构**:

| Industry | Judge Mean | Fan Mean | Gap |
|----------|------------|----------|-----|
| Athlete | 0.4455 | 0.4348 | -0.011 |
| Actor/Actress | 0.4406 | 0.3678 | -0.073 |
| Singer/Rapper | 0.4360 | 0.3908 | -0.045 |
| TV Personality | 0.4096 | 0.3872 | -0.022 |
| Model | 0.3957 | 0.1341 | -0.262 |

```python
import seaborn as sns
import pandas as pd

data = pd.DataFrame({
    'Industry': ['Athlete', 'Actor', 'Singer', 'TV', 'Model'],
    'Judge': [0.4455, 0.4406, 0.4360, 0.4096, 0.3957],
    'Fan': [0.4348, 0.3678, 0.3908, 0.3872, 0.1341]
})

plt.figure(figsize=(10, 6))
heatmap_data = data.set_index('Industry')[['Judge', 'Fan']]
sns.heatmap(heatmap_data, annot=True, cmap='RdYlGn', center=0.35,
            fmt='.3f', linewidths=0.5)
plt.title('Industry Performance: Judge vs Fan')
plt.savefig('industry_heatmap.png', dpi=300)
```

**图表说明**:
- 颜色深浅表示得分高低
- 每个单元格标注具体数值
- 突出显示 Model 行业的极端差距

---

### Figure 5: 效应量对比森林图 (Effect Size Forest Plot)

**图表类型**: 森林图 (Forest Plot)

**推荐设计**:

```
Variable           Judge Effect    Fan Effect      Difference
───────────────────────────────────────────────────────────────
Age (β)            ─────●─────     ───────●───     *** p<0.001
                   -0.06           -0.14
                   
Partner (ICC)      ─────●─────     ──●──           *** p<0.001
                   16.4%           5.0%
                   
Industry (η²)      ──●──           ───●───          NS
                   2.0%            3.0%
                   
Geographic (η²)    N/A             ─────●─────     *** p<0.001
                                   9.5%
───────────────────────────────────────────────────────────────
                   0    5%   10%   15%   20%
```

---

## 3. 假设检验可视化

### Figure 6: 系数差异检验示意图 (Coefficient Comparison Test)

```mermaid
flowchart LR
    subgraph Model_J["评委模型"]
        A["β_Age = -0.059"]
        A1["SE = 0.008"]
    end
    
    subgraph Model_F["粉丝模型"]
        B["β_Age = -0.141"]
        B1["SE = 0.020"]
    end
    
    subgraph Test["Welch's t-test"]
        C["t = (β_J - β_F) / √(SE_J² + SE_F²)"]
        D["t = 4.07"]
        E["p = 0.000055"]
    end
    
    subgraph Conclusion["结论"]
        F["拒绝 H₀"]
        G["年龄效应<br/>存在显著差异"]
    end
    
    A --> C
    B --> C
    A1 --> C
    B1 --> C
    C --> D --> E --> F --> G
```

---

## 4. 舞伴效应详细可视化

### Figure 7: Top 10 舞伴 Premium 排名 (Partner Ranking)

**图表类型**: 水平条形图 (Horizontal Bar Chart)

**推荐设计**:

```
舞伴评委 Premium 排名 (评委视角)
────────────────────────────────────
Allison Holker      ████████████████ +0.26
Daniella Karagach   █████████████ +0.20
Valentin C.         █████████████ +0.20
Mark Ballas         ███████████ +0.16
Derek Hough         ██████████ +0.13
                    0    +0.1   +0.2   +0.3

舞伴粉丝 Premium 排名 (粉丝视角)
────────────────────────────────────
Derek Hough         ██████████████████ +0.29
Daniella Karagach   █████████████████ +0.27
Julianne Hough      █████████████████ +0.27
Valentin C.         █████████████ +0.20
Cheryl Burke        ████████████ +0.18
                    0    +0.1   +0.2   +0.3
```

**关键洞察**: 评委青睐 Allison Holker，粉丝青睐 Derek Hough

---

### Figure 8: 舞伴效应评委-粉丝偏好差异 (Partner Preference Gap)

**图表类型**: 散点图 (Scatter Plot) + 45度参考线

```python
plt.figure(figsize=(10, 10))
plt.scatter(partner_data['Judge_Premium'], 
            partner_data['Fan_Premium'], 
            s=partner_data['Count']*10, alpha=0.6)

# 45度参考线
plt.plot([-0.3, 0.3], [-0.3, 0.3], 'k--', alpha=0.5, label='Equal Preference')

# 标注关键舞伴
for _, row in partner_data.iterrows():
    if abs(row['Gap']) > 0.15:
        plt.annotate(row['Partner'], (row['Judge_Premium'], row['Fan_Premium']))

plt.xlabel('Judge Premium')
plt.ylabel('Fan Premium')
plt.title('Partner Effect: Judge vs Fan Preference')
plt.legend()
```

---

## 5. 地区效应可视化

### Figure 9: 美国地图热力图 (Geographic Effect Map)

**图表类型**: Choropleth Map (地图热力图)

**推荐工具**: plotly / geopandas

**设计要点**:
- 颜色深浅表示各州选手的平均粉丝支持度
- 突出显示高粉丝支持州 (如 Texas, Florida)
- 添加图例说明 η² = 9.5%

---

## 6. 综合结论可视化

### Figure 10: 评委 vs 粉丝评价差异总结图 (Summary Comparison)

```mermaid
graph TB
    subgraph Judge["评委评价驱动因素"]
        J1["🎯 技术表现"]
        J2["👨‍🏫 职业舞伴 (16.4%)"]
        J3["📅 年龄 (β=-0.06)"]
    end
    
    subgraph Fan["粉丝投票驱动因素"]
        F1["🌟 既有人气"]
        F2["📍 地缘认同 (9.5%)"]
        F3["📅 年龄偏见 (β=-0.14, 2.4x)"]
        F4["🎬 行业粉丝基数"]
    end
    
    subgraph Conclusion["核心结论"]
        C["评委与粉丝的评价标准<br/>存在结构性割裂"]
    end
    
    Judge --> C
    Fan --> C
```

---

## 7. 推荐图表清单

| 图编号 | 图表名称 | 类型 | 优先级 |
|--------|----------|------|--------|
| Fig.1 | 双轨归因框架 | 流程图 | ⭐⭐⭐ 必须 |
| Fig.2 | 年龄效应对比 | 条形图+误差线 | ⭐⭐⭐ 必须 |
| Fig.3 | ICC 方差分解 | 饼图对 | ⭐⭐⭐ 必须 |
| Fig.4 | 行业热力图 | 热力图 | ⭐⭐ 推荐 |
| Fig.5 | 效应量森林图 | 森林图 | ⭐⭐ 推荐 |
| Fig.6 | 检验流程图 | 流程图 | ⭐ 可选 |
| Fig.7 | 舞伴排名 | 水平条形图 | ⭐⭐ 推荐 |
| Fig.8 | 舞伴偏好散点 | 散点图 | ⭐ 可选 |
| Fig.9 | 地区热力图 | 地图 | ⭐⭐ 推荐 |
| Fig.10 | 总结对比图 | 概念图 | ⭐⭐⭐ 必须 |

---

## 8. MCM O-Award 可视化设计原则

### 8.1 配色方案
- **评委相关**: 蓝色系 (#3498db, #2980b9)
- **粉丝相关**: 红色系 (#e74c3c, #c0392b)
- **对比/差异**: 橙色 (#f39c12)
- **背景**: 浅灰 (#f5f5f5)

### 8.2 设计原则
1. **清晰性**: 每张图只传达一个核心信息
2. **一致性**: 全文图表使用统一配色和字体
3. **信息密度**: 避免过度装饰，突出数据本身
4. **标注完整**: 包含坐标轴标签、图例、标题、数据来源

### 8.3 MCM 评审关注点
- 图表是否支撑文字结论
- 是否有原创性可视化设计
- 是否清晰展示模型逻辑
- 是否有效传达不确定性 (如置信区间)

---

*本指南为 Task 3 论文可视化提供完整方案，论文手可根据优先级选择实现。*
