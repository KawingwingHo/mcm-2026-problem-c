import matplotlib.pyplot as plt
import matplotlib.patches as patches
import matplotlib.path as mpath
import numpy as np
import os

# Set style
plt.style.use('default')
plt.rcParams['figure.dpi'] = 300
plt.rcParams['font.family'] = 'sans-serif'
try:
    plt.rcParams['font.sans-serif'] = ['Arial Unicode MS', 'SimHei', 'PingFang SC', 'sans-serif']
except:
    pass

def draw_sankey_link(ax, x_start, x_end, y_start_top, y_start_bot, y_end_top, y_end_bot, color, alpha=0.5):
    """Draws a sigmoid link between two vertical segments."""
    # Control points for Bezier curve
    mid_x = (x_start + x_end) / 2
    
    # Top curve
    verts_top = [
        (x_start, y_start_top),
        (mid_x, y_start_top),
        (mid_x, y_end_top),
        (x_end, y_end_top)
    ]
    codes_top = [mpath.Path.MOVETO, mpath.Path.CURVE4, mpath.Path.CURVE4, mpath.Path.CURVE4]
    
    # Bottom curve
    verts_bot = [
        (x_end, y_end_bot),
        (mid_x, y_end_bot),
        (mid_x, y_start_bot),
        (x_start, y_start_bot)
    ]
    codes_bot = [mpath.Path.LINETO, mpath.Path.CURVE4, mpath.Path.CURVE4, mpath.Path.CURVE4]
    
    path_data = verts_top + verts_bot + [(x_start, y_start_top)]
    codes = codes_top + codes_bot + [mpath.Path.CLOSEPOLY]
    
    path = mpath.Path(path_data, codes)
    patch = patches.PathPatch(path, facecolor=color, alpha=alpha, edgecolor='none')
    ax.add_patch(patch)

def plot_controversy_sankey():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    output_dir = os.path.join(base_dir, 'figures')
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    fig, ax = plt.subplots(figsize=(14, 8))
    ax.axis('off')
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 25) # Max value is 22.5
    
    # === Data ===
    # Total Risk: 22.5
    # Rank Filtered: 7.3
    # Rank Remaining: 15.2
    # Judge Save Filtered: 7.9
    # Final Residual: 7.3
    
    # Coordinates
    x_stage1 = 1.0  # Percentage Rule (Start)
    x_stage2 = 5.0  # Rank Rule Split
    x_stage3 = 9.0  # Judge Save Split
    
    # Y-positions (Centering vertically roughly)
    # Start: Height 22.5. Center at 12.5.
    # Top: 12.5 + 11.25 = 23.75
    # Bot: 12.5 - 11.25 = 1.25
    y_start_top = 23.0
    y_start_bot = 0.5
    height_total = y_start_top - y_start_bot # 22.5
    
    # Stage 2: 
    # Top Branch (Filtered by Rank): Height 7.3.
    # Bot Branch (Remaining): Height 15.2.
    # Let's separate them vertically.
    y_s2_filtered_top = 23.0
    y_s2_filtered_bot = 23.0 - 7.3
    
    y_s2_remain_top = 23.0 - 7.3 - 1.0 # Gap of 1.0
    y_s2_remain_bot = y_s2_remain_top - 15.2
    
    # Stage 3 (from s2_remain):
    # Top Branch (Filtered by Judge): Height 7.9
    # Bot Branch (Residual): Height 7.3
    y_s3_filtered_top = y_s2_remain_top
    y_s3_filtered_bot = y_s2_remain_top - 7.9
    
    y_s3_resid_top = y_s3_filtered_bot - 1.0 # Gap
    y_s3_resid_bot = y_s3_resid_top - 7.3
    
    # === Drawing Flows ===
    
    # 1. Start Block
    ax.add_patch(patches.Rectangle((x_stage1-0.2, y_start_bot), 0.4, height_total, color='#C62828')) # Red for Risk
    
    # 2. Flow 1: Intercepted by Rank (Green)
    draw_sankey_link(ax, x_stage1+0.2, x_stage2-0.2, 
                     y_start_top, y_start_top - 7.3, # Taking from top portion
                     y_s2_filtered_top, y_s2_filtered_bot, 
                     color='#81C784', alpha=0.6)
    
    # 3. Flow 2: Remaining Risk (Red)
    draw_sankey_link(ax, x_stage1+0.2, x_stage2-0.2, 
                     y_start_top - 7.3, y_start_bot, # Taking from bottom portion
                     y_s2_remain_top, y_s2_remain_bot, 
                     color='#EF9A9A', alpha=0.6)
    
    # 4. Stage 2 Blocks
    ax.add_patch(patches.Rectangle((x_stage2-0.2, y_s2_filtered_bot), 0.4, 7.3, color='#388E3C')) # Green Block
    ax.add_patch(patches.Rectangle((x_stage2-0.2, y_s2_remain_bot), 0.4, 15.2, color='#D32F2F')) # Red Block
    
    # 5. Flow 3: Intercepted by Judge Save (Green) -> From Remaining
    draw_sankey_link(ax, x_stage2+0.2, x_stage3-0.2,
                     y_s2_remain_top, y_s2_remain_top - 7.9,
                     y_s3_filtered_top, y_s3_filtered_bot,
                     color='#81C784', alpha=0.6)
    
    # 6. Flow 4: Final Residual (Grey/Dark Red) -> From Remaining
    draw_sankey_link(ax, x_stage2+0.2, x_stage3-0.2,
                     y_s2_remain_top - 7.9, y_s2_remain_bot,
                     y_s3_resid_top, y_s3_resid_bot,
                     color='#B0BEC5', alpha=0.6)
                     
    # 7. Stage 3 Blocks
    ax.add_patch(patches.Rectangle((x_stage3-0.2, y_s3_filtered_bot), 0.4, 7.9, color='#388E3C'))
    ax.add_patch(patches.Rectangle((x_stage3-0.2, y_s3_resid_bot), 0.4, 7.3, color='#455A64'))
    
    # === Annotations (HEAVY FONT) ===
    
    # Start
    ax.text(x_stage1, y_start_top + 0.5, "Total Risky Events\n(Percentage Rule)", ha='center', fontweight='heavy', fontsize=16)
    ax.text(x_stage1, y_start_bot + height_total/2, "22.5%", ha='center', va='center', color='black', fontweight='heavy', fontsize=20)
    
    # Middle Top (Rank Filter)
    ax.text(x_stage2, y_s2_filtered_top + 0.5, "Intercepted by\nRank Rule", ha='center', fontweight='heavy', fontsize=14, color='#2E7D32')
    ax.text(x_stage2, y_s2_filtered_bot + 3.6, "7.3%\n(Magnitude\nCompression)", ha='center', va='center', color='black', fontweight='heavy', fontsize=12)
    
    # Middle Bot (Rank Remain)
    ax.text(x_stage2, y_s2_remain_bot - 1.5, "Remaining Risk\n(Rank Rule Only)", ha='center', fontweight='heavy', fontsize=14, color='#C62828')
    ax.text(x_stage2, y_s2_remain_bot + 7.6, "15.2%", ha='center', va='center', color='black', fontweight='heavy', fontsize=18)
    
    # End Top (Judge Save)
    ax.text(x_stage3, y_s3_filtered_top + 0.5, "Intercepted by\nJudge Save", ha='center', fontweight='heavy', fontsize=14, color='#2E7D32')
    ax.text(x_stage3, y_s3_filtered_bot + 3.9, "7.9%\n(Manual\nCorrection)", ha='center', va='center', color='black', fontweight='heavy', fontsize=12)
    
    # End Bot (Residual)
    ax.text(x_stage3, y_s3_resid_bot - 1.5, "Residual Controversy\n(Unavoidable)", ha='center', fontweight='heavy', fontsize=14, color='#455A64')
    ax.text(x_stage3, y_s3_resid_bot + 3.6, "7.3%", ha='center', va='center', color='black', fontweight='heavy', fontsize=18)
    
    # Title
    ax.text(5, 26, "Flow of Controversy Filtration: From Populism to Professionalism", ha='center', fontweight='heavy', fontsize=22)
    
    # Save
    pdf_path = os.path.join(output_dir, 'controversy_sankey.pdf')
    png_path = os.path.join(output_dir, 'controversy_sankey.png')
    
    plt.savefig(pdf_path, bbox_inches='tight')
    plt.savefig(png_path, dpi=300, bbox_inches='tight')
    
    print(f"Sankey diagram saved to:\n- {pdf_path}\n- {png_path}")

if __name__ == "__main__":
    plot_controversy_sankey()
