import matplotlib.pyplot as plt
import numpy as np
import os
import matplotlib.colors as mcolors

# Set style
plt.style.use('default')
plt.rcParams['figure.dpi'] = 300
plt.rcParams['font.family'] = 'sans-serif'
try:
    plt.rcParams['font.sans-serif'] = ['Arial Unicode MS', 'SimHei', 'PingFang SC', 'sans-serif']
    plt.rcParams['axes.unicode_minus'] = False
except:
    pass

def plot_game_evolution_heatmap():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    output_dir = os.path.join(base_dir, 'figures')
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    # === Simulation Parameters ===
    # We compare Contestant A (Lower Judge, Higher Fan) vs Contestant B (Higher Judge, Lower Fan)
    # X-axis: Judge Gap (B - A). 0 to 1.0 (Normalized)
    # Y-axis: Fan Gap (A - B). 0 to 5.0 (Normalized, Fan gap can be huge due to outliers)
    
    grid_size = 100
    judge_gaps = np.linspace(0, 0.5, grid_size) # Judge scores usually within range
    fan_gaps = np.linspace(0, 2.0, grid_size)   # Fan gaps can be large
    
    X, Y = np.meshgrid(judge_gaps, fan_gaps)
    
    # Weight (Standard 50/50 for illustration of mechanism)
    w = 0.5 
    
    # === 1. Percentage Rule Probability ===
    # Score A = w*Ja + (1-w)*Fa
    # Score B = w*Jb + (1-w)*Fb
    # Upset if A > B => w(Ja - Jb) + (1-w)(Fa - Fb) > 0
    # => (1-w)(FanGap) - w(JudgeGap) > 0
    # => FanGap > (w/(1-w)) * JudgeGap
    # This is deterministic for fixed gaps, but let's assume some uncertainty/noise in the "Gap" measurement
    # Or just plot the Decision Boundary which is linear.
    # To make it a "Probability" heatmap, we can add small gaussian noise to the realization.
    
    Z_pct = np.zeros_like(X)
    n_sim = 100
    for i in range(grid_size):
        for j in range(grid_size):
            jg = X[i, j]
            fg = Y[i, j]
            
            # Simulate realizations
            # Adding noise to represent uncertainty in the exact "Gap" value vs "Score" outcome
            noise_j = np.random.normal(0, 0.05, n_sim)
            noise_f = np.random.normal(0, 0.05, n_sim)
            
            # Deterministic Score Difference
            # Diff = (1-w)*(fg + noise_f) - w*(jg + noise_j)
            diff = (1-w)*(fg) - w*(jg) + np.random.normal(0, 0.1, n_sim)
            
            upset_prob = np.mean(diff > 0)
            Z_pct[i, j] = upset_prob

    # === 2. Rank Rule Probability ===
    # In Rank Rule, Gaps are converted to Point Differences.
    # Judge Gap > Threshold -> 1 Point Judge Diff, > Threshold2 -> 2 Points Judge Diff.
    # Fan Gap > Threshold -> 1 Point Fan Diff, etc.
    # But Points are CAPPED.
    # A huge Fan Gap (e.g. 1 million votes vs 10 votes) is still just "Rank 1 vs Rank 2" (Diff = 1 point) or "Rank 1 vs Rank N" (Diff = N points).
    # But Judge Points are also Rank based.
    # Standard logic: Upset happens if Fan Rank Points Diff > Judge Rank Points Diff.
    # Key difference: Fan Gap Magnitude acts as a Step Function.
    
    Z_rank = np.zeros_like(X)
    
    # We model Rank Conversion function
    def get_rank_points_diff(gap, steepness=10):
        # Logistic function to simulate "Gap -> Rank Difference" probability
        # Large gap -> High prob of Max Rank Diff
        # Max Diff is bounded (e.g. max 5 points)
        return 5 * (1 / (1 + np.exp(-steepness * gap)) - 0.5) * 2 # Scaed 0 to 5 roughly
    
    # But simpler: 
    # Judge Points Diff = f(Judge Gap)
    # Fan Points Diff = f(Fan Gap)
    # But Fan Gap maps to points differently? No, symmetric usually.
    # The KEY is that Fan Gap in Percentage is UNBOUNDED in impact.
    # In Rank, Fan Gap impact is BOUNDED.
    
    # While testing Z_pct, we used Linear Impact: (1-w)*FG.
    # For Z_rank, we use Bounded Impact: (1-w)*Bounded(FG) - w*Bounded(JG).
    
    for i in range(grid_size):
        for j in range(grid_size):
            jg = X[i, j]
            fg = Y[i, j]
            
            # Bounded Impact Simulation
            # Fan Gap impact saturates at, say, 0.5 (normalized scale equivalent)
            fg_effective = np.tanh(fg * 3) * 0.5 
            jg_effective = np.tanh(jg * 3) * 0.5
            
            diff = (1-w)*fg_effective - w*jg_effective + np.random.normal(0, 0.1, n_sim) 
            
            # Wait, if both saturate, it behaves like linear near zero?
            # The point is: If JG is large (saturated), and FG is HUGE (saturated), they cancel?
            # In Percentage: If JG is large, FG is HUGE -> FG wins (Upset).
            # In Rank: If JG is large (max points), FG is HUGE (max points) -> Tie/Cancel. Upset prob is 50/50 or lower.
            # So Rank protects high Judge scores from Infinite Fan votes.
            
            upset_prob = np.mean(diff > 0)
            Z_rank[i, j] = upset_prob
            
    # === Plotting ===
    # Use constrained_layout to automatically handle spacing and colorbars
    fig, axes = plt.subplots(1, 2, figsize=(16, 7), layout='constrained')
    
    # Custom colormap: Blue (Safe) to Red (Upset)
    cmap = plt.cm.RdYlBu_r
    
    # Plot 1: Percentage
    im1 = axes[0].pcolormesh(X, Y, Z_pct, cmap=cmap, shading='auto', vmin=0, vmax=1)
    axes[0].set_title("Percentage Rule: Open Upset Zone\n(Susceptible to Populism)", fontsize=18, fontweight='bold')
    axes[0].set_xlabel("Judge Score Gap (Professionalism)", fontsize=14, fontweight='bold')
    axes[0].set_ylabel("Fan Vote Gap (Popularity)", fontsize=14, fontweight='bold')
    
    # Add diagonal line y = x (approx)
    axes[0].plot([0, 0.5], [0, 0.5], 'k--', lw=3, alpha=0.5)
    axes[0].text(0.3, 1.5, "High Probability of\nPopulist Upset\n(Red Zone Intrusion)", 
                 color='black', fontsize=14, fontweight='bold', ha='center',
                 bbox=dict(facecolor='white', alpha=0.7, edgecolor='none', pad=2)) # Added background for readability
    
    # Plot 2: Rank
    im2 = axes[1].pcolormesh(X, Y, Z_rank, cmap=cmap, shading='auto', vmin=0, vmax=1)
    axes[1].set_title("Rank Rule: Bounded Upset Zone\n(Professional Safeguard)", fontsize=18, fontweight='bold')
    axes[1].set_xlabel("Judge Score Gap (Professionalism)", fontsize=14, fontweight='bold')
    axes[1].set_ylabel("Fan Vote Gap (Popularity)", fontsize=14, fontweight='bold')
    
    # Add diagonal line
    axes[1].plot([0, 0.5], [0, 0.5], 'k--', lw=3, alpha=0.5)
    axes[1].text(0.3, 0.3, "Safe Zone\n(Diagonal Constraint)", 
                 color='darkblue', fontsize=14, fontweight='bold', ha='center',
                 bbox=dict(facecolor='white', alpha=0.7, edgecolor='none', pad=2))
    
    # Colorbar - Placed on the right, not overlapping
    cbar = fig.colorbar(im1, ax=axes[1], shrink=0.8, pad=0.02)
    cbar.set_label("Probability of Upset (Low Judge Score Wins)", fontsize=14, fontweight='bold')
    cbar.ax.tick_params(labelsize=12) 
    for l in cbar.ax.yaxis.get_ticklabels():
        l.set_fontweight('bold')

    # Tick params for axes
    for ax in axes:
        ax.tick_params(axis='both', which='major', labelsize=12)
        for label in ax.get_xticklabels() + ax.get_yticklabels():
            label.set_fontweight('bold')
    
    # Save (No tight_layout needed with constrained_layout)
    pdf_path = os.path.join(output_dir, 'game_evolution_heatmap.pdf')
    png_path = os.path.join(output_dir, 'game_evolution_heatmap.png')
    
    plt.savefig(pdf_path, bbox_inches='tight')
    plt.savefig(png_path, dpi=300, bbox_inches='tight')
    
    print(f"Heatmap saved to:\n- {pdf_path}\n- {png_path}")

if __name__ == "__main__":
    plot_game_evolution_heatmap()
